DigiVanta Dashboard preview
Open index.html directly in Chrome.
This version has all CSS and JavaScript inline, so it works by double-clicking index.html.
It is a front-end prototype: buttons/menu are visual navigation only until a backend is connected.
